﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuAction : MonoBehaviour
{
    protected bool pausedMenu = false; // overrides all other menus
    protected bool abilityMenu = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        checkPaused();
        checkAbilityWheel();
    }

    // pause is toggle
    protected void checkPaused()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Debug.Log("Paused");
            if (!pausedMenu)
            {
                pausedMenu = true;
                Time.timeScale = 0;
            }
            else
            {
                pausedMenu = false;
                Time.timeScale = 1;
            }
        }
    }

    // wheel is hold
    protected void checkAbilityWheel()
    {
        if (!pausedMenu)
        {
            abilityMenu = Input.GetKey(KeyCode.Tab);
            if (abilityMenu)
            {
                abilityMenu = true;
                Time.timeScale = .05f;
            }
            else
            {
                abilityMenu = false;
                Time.timeScale = 1;
            }
        }
    }
}
