﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : Player
{
    // local variables for internal workings
    private float nextDash = 0f; // timer for next dash
    private float prevDash = 0f; // tracks time of previous dash for cooldown tracking

    /*
     * function returns whether the max number of jumps before 'grounded' has been hit or not
     */
    private bool jumpExhausted()
    {
        return jumpCount >= maxJumps;
    }


    /* 
     * function computes physics properties of basic lateral and vertical movement
     * does not actually move the character. just provides the value that does
     */
    protected override void ComputeVelocity()
    {
        Vector2 move = Vector2.zero;

        move.x = Input.GetAxis("Horizontal");

        if (Input.GetButtonDown("Jump") && !jumpExhausted())
        {
            Debug.Log(jumpCount);
            velocity.y = jumpTakeOffSpeed;
            jumpCount++;
        }
     

        if (velocity.y > 0)
        {
            velocity.y = velocity.y * 0.98f;  // jump decay rate
        }
        if(velocity.y < 0 && velocity.y > terminalVelocity)
        {
            velocity.y = velocity.y * 1.02f;  // gravitational acceleration rate
        }

        if (move.x > 0.01f)
        {
            if (spriteRenderer.flipX == true)
            {
                spriteRenderer.flipX = false;
            }
        }
        else if (move.x < -0.01f)
        {
            if (spriteRenderer.flipX == false)
            {
                spriteRenderer.flipX = true;
            }
        }

        animator.SetBool("grounded", grounded);
        animator.SetFloat("velocityXnonNormal", Mathf.Abs(velocity.x)); 
        animator.SetFloat("velocityX", Mathf.Abs(velocity.x) / maxSpeed);
        animator.SetFloat("velocityY", velocity.y);

        targetVelocity = move * maxSpeed;
    }

    /*
     * function handles abilities that are NOT tied to basic lateral or vertical movement
     */
    protected override void HandleMoveAbilities()
    {
        // **CROUCH CODE (hardcoded for debugging purposes)**
        if (crouchKeyPressed)
        { 
            if (capCollider.size.y == .7f)                                                  // crouches only if he isn't already crouching, technically just drops and holds the collider
            {
                capCollider.size -= new Vector2(0, .3f);
                capCollider.offset = new Vector2(0, -.2f);
                maxSpeed *= .6f;
            }
        }
        else
        {
            if (capCollider.size.y != .7f)                                                  // only runs if he isn't crouching, cancels the crouch
            {
                capCollider.size += new Vector2(0, .3f);
                capCollider.offset = new Vector2(0, -.055f);
            }
        }
        
        // **DASH CODE**
        if (dashKeyPressed)
        {
            // if dashing
            if (Time.time > nextDash)
            {
                spriteRenderer.color = sColor;
                Debug.Log("Dashed!");
                if (spriteRenderer.flipX == false)
                    rb2d.AddForce(Vector2.right * dashTakeOffSpeed, ForceMode2D.Impulse);
                else
                    rb2d.AddForce(Vector2.left * dashTakeOffSpeed, ForceMode2D.Impulse);
                prevDash = Time.time;                                                       // slice set for waiting
                nextDash = Time.time + dashCD;                                              // increment nextDash by the cooldown time
            }
            // if dash blocked for cooldown
            else if(prevDash + .5f < Time.time)                                             // .5 second window before turning attemptDash on cooldown trigger
            {
                spriteRenderer.color = cdColor;
                colorReturn = Time.time + colorStatusCD;                                    // increment color return by cooldown time
                Debug.Log("On coolDown! " + (nextDash-Time.time) + "seconds left");
            }
        }
        if (spriteRenderer.color == cdColor && Time.time > colorReturn)                     // remove effect that shows dash is on cooldown after .2 seconds pass
            spriteRenderer.color = sColor;

        // reset all keyPress bools
        dashKeyPressed = false;
        crouchKeyPressed = false;                                                           // set back so if player stops holding, crouch will stop next frame

        // animator properties
        animator.SetFloat("SteveSize", capCollider.size.y);
    }

}
