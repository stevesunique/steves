﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : PhysicsObject
{
    // player speed
    protected float maxSpeed = 7f;          //direct influence of character speed
    protected float maxSpeedLock = 7f;

    // jump focused
    protected float jumpTakeOffSpeed = 8;   // jump height
    protected int maxJumps = 1;             // num jumps allowed before grounded

    // dash focused
    protected int dashTakeOffSpeed = 8;     // dash speed
    protected float dashCD = 3f;            // dash cooldown

    // attack strength focused *nothing here yet b/c no player attack
   
    // sprite focused
    protected float colorStatusCD = .1f;    // duration of color status cooldown
    protected float colorReturn = 0f;       // timer for duration of color status cooldown
    protected SpriteRenderer spriteRenderer;
    protected Animator animator;
    protected Color sColor;
    protected Color cdColor = Color.red;

    // keypress booleans
    protected bool dashKeyPressed = false;
    protected bool eyeBeamKeyPressed = false;  // doesn't *actually* exist yet, or probably at all
    protected bool crouchKeyPressed = false;
    protected bool menuButtonPressed = false;  // needed due to how timescale alters physics

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        sColor = spriteRenderer.color;
        cdColor.a = .9f;
    }

    protected override void HandlePlayer()
    {
        UpdateAbilities();
        ComputeVelocity();
    }

    protected override void HandlePlayerFixed()
    {
        HandleKeyPress();
        HandleMoveAbilities();
    }

    /*
    * function handles key presses tied to player abilities
    */
    protected void HandleKeyPress()
    {
        if (!dashKeyPressed)
            dashKeyPressed = Input.GetKey(KeyCode.LeftShift);

        if (!crouchKeyPressed)
            crouchKeyPressed = Input.GetKey(KeyCode.S);
    }

    /*
     * function handles the updates tied to character movement stats.
     * serves as upgrades to the players movement and abilities.
     * references characterstats static instance which is updated
     * on certain triggers.
     */
    protected void UpdateAbilities()
    {
        // keep movement abilities updated
        if (CharacterStats.instance.CmaxSpeed > maxSpeed)
        {
            if (!crouchKeyPressed)                                               // max speed is modified by crouch, will be returned to normal when not crouched
                maxSpeed = CharacterStats.instance.CmaxSpeed;
        }
        if (CharacterStats.instance.CjumpTakeOffSpeed > jumpTakeOffSpeed)
        {
            jumpTakeOffSpeed = CharacterStats.instance.CjumpTakeOffSpeed;
        }
        if (CharacterStats.instance.CmaxJumps > maxJumps)
        {
            maxJumps = CharacterStats.instance.CmaxJumps;
        }
        if (CharacterStats.instance.CdashTakeOffSpeed > dashTakeOffSpeed)
        {
            dashTakeOffSpeed = CharacterStats.instance.CdashTakeOffSpeed;
        }
        if (CharacterStats.instance.CdashCD < dashCD)
        {
            dashCD = CharacterStats.instance.CdashCD;
        }
    }

    protected virtual void HandleMoveAbilities()
    {

    }
    protected virtual void ComputeVelocity()
    {

    }
}
