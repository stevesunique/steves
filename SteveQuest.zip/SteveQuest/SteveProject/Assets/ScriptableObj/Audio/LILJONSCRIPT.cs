﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LILJONSCRIPT : MonoBehaviour
{
    public AudioSource audioclipLJ;
    private CircleCollider2D bgDampener;
    public bool entered = false;
    void Start()
    {
        audioclipLJ = GetComponent<AudioSource>();
        bgDampener = GetComponent<CircleCollider2D>();
        audioclipLJ.spatialBlend = 1;
        audioclipLJ.volume = 1;
        audioclipLJ.playOnAwake = true;
        audioclipLJ.loop = true;
        audioclipLJ.maxDistance = 11;
        audioclipLJ.minDistance = 1;
        audioclipLJ.rolloffMode = AudioRolloffMode.Linear;
        bgDampener.isTrigger = true;

        bgDampener.radius = 10;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            Debug.Log("Collision Entered");
            
        }
    }
    
    void OnTriggerExit2D(Collider2D collision)
    {
        Debug.Log("Collision Exited");
        if (collision.gameObject.tag == "Player")
        {
            
        }
    }

}
