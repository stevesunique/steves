﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPickup : Interactables
{
    public Item item;
    CharacterStats cStats;

    public override void interact()
    {
        base.interact();
        PickUp();
    }

    void PickUp()
    {
        item.use();
        Destroy(gameObject);
    }
}
