﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Orb", menuName = "World/item/orb")]
public class Orb : Item
{
    public int healthMod;
    public bool buffMaxHealth;
    public bool buffMoveSpeed;
    public bool buffJumpHeight;
    public bool buffJumpCount;
    public bool buffDashDistance;
    public bool buffDashCoolDown;
    public CharacterStats cStats;

    void start()
    {
     
    }

    public override void use()
    {
        base.use(); // call base to perform any universal "item" functionality
        ApplyEffect();
    }

    public void ApplyEffect()
    {
        
        CharacterStats.instance.GainHealth(healthMod);
        CharacterStats.instance.GainMaxHealth(buffMaxHealth, healthMod);
        CharacterStats.instance.GainMoveSpeed(buffMoveSpeed);
        CharacterStats.instance.GainJumpHeight(buffJumpHeight);
        CharacterStats.instance.GainJumpCount(buffJumpCount);
        CharacterStats.instance.GainDashDistance(buffDashDistance);
        CharacterStats.instance.GainDashCooldown(buffDashCoolDown);
    }
}
