﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// this allows you to create a frame for distinct items in unity
// can have subclasses per item from this
[CreateAssetMenu(fileName = "New Item", menuName = "World/item")]
public class Item : ScriptableObject
{
    new public string name = "Item";
    public SpriteRenderer icon = null;
    public Color color = default;

    public virtual void use()
    {

    }
}
